from flask import Flask, request, render_template
import os

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        ipa_file = request.files.get('ipa_file')
        p12_file = request.files.get('p12_file')
        mobileprovision_file = request.files.get('mobileprovision_file')
        password = request.form.get('password')

        if ipa_file and p12_file and mobileprovision_file and password:
            # Create uploads folder if it doesn't exist
            if not os.path.exists("uploads"):
                os.makedirs("uploads")

            ipa_path = os.path.join("uploads", ipa_file.filename)
            p12_path = os.path.join("uploads", p12_file.filename)
            mobileprovision_path = os.path.join("uploads", mobileprovision_file.filename)

            ipa_file.save(ipa_path)
            p12_file.save(p12_path)
            mobileprovision_file.save(mobileprovision_path)

            return f"""Files received successfully:<br>
                       IPA: {ipa_file.filename}<br>
                       P12: {p12_file.filename}<br>
                       Provisioning: {mobileprovision_file.filename}<br>
                       Password: {password}"""

        return "Missing file(s) or password."

    # Load the form page
    return render_template("index.html")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)